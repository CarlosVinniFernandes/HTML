function alterarNome(params) {
        let nome;
    
        nome = document.getElementById('y').value;
    
        var a = document.getElementById('x');
        
        a.innerText = "Be happy, " + nome;
}